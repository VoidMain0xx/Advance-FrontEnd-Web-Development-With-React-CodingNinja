// Complete the Form Component and export it

const Form = () => (
  <>
    <div>
      <form>{/* Create a h3, 2 inputs and 1 button here */}
      <h3>login</h3>
      <input type="text" placeholder="YourName"/>
      <input type="text" placeholder="xyz@pqr.com"/>
      <button>submit</button>
      </form>
    </div>
  </>
);

export default Form;
