// Create About component here to display the a small content here.
// In this component use paragraph tag (p) to display the content

import { Component } from "react";

class About extends Component{
    render(){
        return (
            <p>Hi I am pranav. I am A full Stack Web Developer and I have developed several projects With MERN Stack. I am also familiar with Python and Django</p>     
        )
    }
}

export default About;
