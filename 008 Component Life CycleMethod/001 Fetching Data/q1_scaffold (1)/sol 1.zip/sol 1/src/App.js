import "./styles.css";
import React from "react";
import Image from "./components/Image";

export default class App extends React.Component {
  constructor() {
    super();
    this.state = {
      photos: [],
      loading: false
    };
  }

 

  componentDidMount(){
    console.log("Component Mount");
    fetch('https://jsonplaceholder.typicode.com/albums/1/photos')
    .then(Response => Response.json())
    .then(data => this.setState({photos : data}))
    .finally(() => this.setState({loading : false}))
  }

  // Use the required lifecycle methods here

  render() {
    // Display loading status here
    if(this.state.loading){
      return( 
        <p>loading....</p>
      )
    }
    return (
      <div className="App">
        {this.state.photos.map((photo) => {
          return <Image key={photo.id} photo={photo} />;
        })}
      </div>
    );
  }
}
