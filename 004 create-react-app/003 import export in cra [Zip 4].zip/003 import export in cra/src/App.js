import "./styles.css";
import HomePage from './HomePage.js'

export default function App() {
  return <div className="App"> <HomePage /> </div>;
}
