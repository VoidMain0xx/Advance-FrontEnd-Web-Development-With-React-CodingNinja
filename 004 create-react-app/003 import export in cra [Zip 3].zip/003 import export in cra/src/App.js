import "./styles.css";
import HomePage from './HomePage.js'
import Form from "./Form.js";

export default function App() {
  return <div className="App"> <HomePage /> </div>;
}
